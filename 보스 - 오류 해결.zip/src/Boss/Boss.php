<?php
 
namespace Boss;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;

use pocketmine\utils\Config;
use pocketmine\Player;

use pocketmine\item\Item;

use pocketmine\command\{
	
	Command,
	CommandSender
	
};

use pocketmine\entity\{

	Zombie,
	Entity

};

use pocketmine\event\entity\{

	EntityDamageByEntityEvent,
	EntityDeathEvent

};

class Boss extends PluginBase implements Listener
{

	public function onEnable ()
	{

		$this->getLogger()->info ('보스 플러그인이 정상적으로 작동하고 있습니다');
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		
		$this->BossData = new Config($this->getDataFolder() . "Boss.yml", Config::YAML, [

			'공격력' => 5,
			'체력' => 30000,
			'크기' => 6,
			'아이템' => []

		]);
		$this->db = $this->BossData->getAll();

	}
	
	public function onDamage (EntityDamageByEntityEvent $event)
	{
		
		$entity = $event->getEntity();
		
		if ($entity->getNameTag() === '보스' && $event->getDamager() instanceof Player) {
			
			$event->setBaseDamage ($this->db ['공격력']);
		
		}
		
	}
	
	public function onDeath (EntityDeathEvent $event)
	{
		
		if ($event->getEntity()->getNameTag() !== '보스') return true;
		
		$dropItem = [];
		
		foreach ($this->db ['아이템'] as $items) {
			
			$dropItem[] = Item::jsonDeserialize ($items);
			
		}

		$event->setDrops ($dropItem);

	}

	public function onCommand (CommandSender $sender, Command $command, string $label, array $args) : bool
	{

		if ($command->getName() === '보스') {
			
			if (! isset ($args[0])) $args[0] = 'x';
			
			switch ($args[0]) {
				
				case '체력':
				case '공격력':
				case '크기':
				
					if (! isset ($args[1])) {
						
						$sender->sendMessage ('보스의 ' . $args[0] . '을(를) 입력해주세요');
						return true;
						
					}
					
					if (! is_numeric ($args[1])) {
						
						$sender->sendMessage ('보스의 ' . $args[0] . '은(는) 숫자로 입력해주세요');
						return true;
						
					}
					
					$this->db [$args[0]] = $args[1];
					
					$this->BossData->setAll ($this->db);
					$this->BossData->save();
					
					$sender->sendMessage ('보스의 기본 ' . $args[0] . '을(를) ' . $args[1] . ' (으)로 설정하였습니다!');
					return true;

				break;
				
				case '소환':

					$database = $this->db;
					$nbt = Entity::createBaseNBT($sender, null, $sender->getYaw(), $sender->getPitch());
					
					$entity = new Zombie ($sender->getLevel(), $nbt);
					$entity->setMaxHealth ($database ['체력']);
					$entity->setHealth ($database ['체력']);
					$entity->setScale ($database ['크기']);
					$entity->setNameTag ('보스');
					$entity->setNameTagAlwaysVisible ();
					$entity->spawnToAll($sender);
					
					$sender->sendMessage ('보스를 소환했습니다!');
					
					return true;
					
				break;
				
				case '아이템':
				
					$count = $args[1] ?? 'x';
					
					if (! is_numeric ($count)) {
						
						$sender->sendMessage ('드랍템 아이템의 개수를 숫자로 입력해주세요');
						return true;
						
					}
					
					$item = $sender->getInventory()->getItemInHand()->jsonSerialize();
					$item ['count'] = $count;
					
					$this->db ['아이템'][] = $item;
					$sender->sendMessage ('아이템을 등록했습니다');
					
					$this->BossData->setAll ($this->db);
					$this->BossData->save();
					
					return true;
					
				break;
				
				default:
				
					foreach ([
					
						'/보스 체력 (int) | 보스의 기본 체력을 설정합니다',
						'/보스 공격력 (int) | 보스의 공격력을 설정합니다',
						'/보스 크기 (int) | 보스의 크기를 설정합니다',
						'/보스 소환 | 보스를 소환합니다',
						'/보스 아이템 (개수) | 보스의 드랍템을 추가합니다'
						
					] as $msg) $sender->sendMessage ($msg);
					
					return true;
					
				break;
				
			}
			
		}
		
	}
	
}